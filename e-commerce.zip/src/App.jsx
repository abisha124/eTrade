import React from 'react';
import Header from './components/header'
import HeroSection from './pages/herosection'
import CategorySection from './pages/categorysection'
import Enhance from './pages/enhance'
import Explore from './pages/explore'
import Footer from './components/footer'


export default function App() {
  return (
    <div >
      
      <Header/>
      <HeroSection/>
      <CategorySection/>
      <Enhance/>
      <Explore/>
      <Footer/>
    </div>
  );
}