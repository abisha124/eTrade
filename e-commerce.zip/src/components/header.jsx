import React from "react";
import styles from "./header.module.css";

export default function Header() {
  return (
    <div className={styles.container}>
    <div className={styles.header}>
      <div className={styles.logo}>
        <h2>eTrade</h2>
      </div>

      <nav className={styles.nav}>
        <ul>
          <li><a href="/">Home</a></li>
          <li><a href="/shop">Shop</a></li>
          <li><a href="/pages">Pages</a></li>
          <li><a href="/blog">Blog</a></li>
          <li><a href="/contact">Contact</a></li>
        </ul>
      </nav>

      <div className={styles.menu}>
        <input
          type="text"
          placeholder="Search products..."
          className={styles.searchInput}/>
        <div className={styles.icons}>
          <span title="Profile">👤</span>
          <span title="Wishlist">❤️</span>
          <span title="Cart">🛒</span>
        </div>
      </div>
    </div>
    </div>
  );
}
