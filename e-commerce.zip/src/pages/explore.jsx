import React from "react";
import styles from "./explore.module.css";
import im1 from "../assets/gaming1 (1).png";
import im2 from "../assets/key.png";
import im3 from "../assets/cam.png";
import im4 from "../assets/speaker.png";

export default function Explore() {
  const products = [
    {id: 1,name: "Tactic Leather & Canvas Edge",brand: "S40",img: im1,oldPrice: "$39.99",newPrice: "$29.99",rating: 4,discount: "25% OFF",},
    {id: 2,name: "Level 20 RGB Cherry",brand: "Thermaltake",img: im2,oldPrice: "$39.99",newPrice: "$29.99",rating: 4,discount: "25% OFF",},
    {id: 3,name: "Logitech Streamcam",brand: "Logitech",img: im3,oldPrice: "$39.99",newPrice: "$29.99",rating: 4,discount: "25% OFF",},
    {id: 4,name: "Z30™ wireless headset",brand: "S40",img: im4,oldPrice: "$39.99",newPrice: "$29.99",rating: 4,discount: "25% OFF",},];
    const products1 = [
    {id: 1,name: "Tactic Leather & Canvas Edge",brand: "S40",img: im1,oldPrice: "$39.99",newPrice: "$29.99",rating: 4,discount: "25% OFF",},
    {id: 2,name: "Level 20 RGB Cherry",brand: "Thermaltake",img: im2,oldPrice: "$39.99",newPrice: "$29.99",rating: 4,discount: "25% OFF",},
    {id: 3,name: "Logitech Streamcam",brand: "Logitech",img: im3,oldPrice: "$39.99",newPrice: "$29.99",rating: 4,discount: "25% OFF",},
    {id: 4,name: "Z30™ wireless headset",brand: "S40",img: im4,oldPrice: "$39.99",newPrice: "$29.99",rating: 4,discount: "25% OFF",},];
  return (
    <div className={styles.productSec}>
      <p className={styles.subtitle}>Our Products</p>
      <h2 className={styles.title}>Explore our Products</h2>

      <div className={styles.grid}>
        {products.map((product) => (
          <div key={product.id} className={styles.card}>
            <div className={styles.imageWrapper}>
              <img src={product.img} alt={product.name} className={styles.image} />
              <span className={styles.discount}>{product.discount}</span>
            </div>
            <div className={styles.info}>
              <div className={styles.rating}>⭐⭐⭐⭐ <span>({product.rating})</span></div>
              <p className={styles.brand}>{product.brand}</p>
              <h3 className={styles.name}>{product.name}</h3>
              <div className={styles.price}>
                <span className={styles.newPrice}>{product.newPrice}</span>
                <span className={styles.oldPrice}>{product.oldPrice}</span>
              </div>

            </div>
           </div> 
        ))}
        <div className={styles.getprod}>
              <button  type="submit">View All products</button>
          </div>
        
      </div>
      
    </div>
  );
}
